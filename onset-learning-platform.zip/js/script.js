
let courses = []
let quizzes = []

function publishCourse(){

  let title=document.getElementById("courseTitle").value
  let price=document.getElementById("coursePrice").value

  let course={title,price}
  courses.push(course)

  renderCourses()

}

function renderCourses(){

  let html=""

  courses.forEach((c,i)=>{

    html+=`
      <div>
        <h3>${c.title}</h3>
        <p>Price: ₹${c.price}</p>
        <button onclick="startQuiz()">Start Quiz</button>
      </div>
    `

  })

  document.getElementById("courseList").innerHTML=html

}

function createQuiz(){

  let q={
    question:document.getElementById("question").value,
    options:[
      document.getElementById("op1").value,
      document.getElementById("op2").value,
      document.getElementById("op3").value,
      document.getElementById("op4").value
    ],
    correct:document.getElementById("correct").value
  }

  quizzes.push(q)

  alert("Quiz Created")

}

function startQuiz(){

  if(quizzes.length===0){
    alert("No quiz created yet")
    return
  }

  let q=quizzes[0]

  let html=`
    <p>${q.question}</p>
    <button onclick="answer(1)">${q.options[0]}</button>
    <button onclick="answer(2)">${q.options[1]}</button>
    <button onclick="answer(3)">${q.options[2]}</button>
    <button onclick="answer(4)">${q.options[3]}</button>
  `

  document.getElementById("quizBox").innerHTML=html

}

function answer(sel){

  let q=quizzes[0]

  if(sel==q.correct){
    alert("Correct!")
  }else{
    alert("Wrong!")
  }

}
