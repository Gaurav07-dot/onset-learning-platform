
# Onset Learning Platform

Simple starter project for a learning platform.

Features:
- Create courses
- Basic quiz system
- Simple UI

Project structure:

onset-learning-platform
│
├── index.html
├── css
│   └── style.css
├── js
│   └── script.js
└── README.md

How to run:
1. Download the project
2. Open index.html in a browser

How to upload to GitHub:
1. Create a repository
2. Upload these files
3. Deploy with Vercel
